
#include <unistd.h>
#include <limits.h>

int main(int argv, char **argc){
    return sleep(INT_MAX);
}
