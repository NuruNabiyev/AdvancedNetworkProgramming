#ifndef ATR_TUNTAP_DEBUG_H
#define ATR_TUNTAP_DEBUG_H

#define __ANP_SHOW__ do {                                                           \
    printf(" NYI: file %s function %s line %d \n", __FILE__, __FUNCTION__, __LINE__); \
} while(0);



#endif //ATR_TUNTAP_DEBUG_H
