#ifndef ANPNETSTACK_INIT_H
#define ANPNETSTACK_INIT_H

void _init_anp_netstack();

#endif //ANPNETSTACK_INIT_H
