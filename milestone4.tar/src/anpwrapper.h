#ifndef ANPNETSTACK_ANPWRAPPER_H
#define ANPNETSTACK_ANPWRAPPER_H

void _function_override_init();

#endif //ANPNETSTACK_ANPWRAPPER_H
