while read F  ; do
        echo $F
done <~/gits/AdvancedNetworkProgramming/goodports
