#!/bin/bash

FILE=/dev/net/tap

if `fd tap /dev/net`; then
    echo "$FILE exists."
fi
